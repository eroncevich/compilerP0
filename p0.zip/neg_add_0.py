x = 2
print -(1 + x)
# x=1
# y=1+3
# z=1+x+5
# y=y+1
# x=y=z=4
# z=-z
# y=input()+x+1
# print x
# print y
# print x+1+y
# print z+(-1)
